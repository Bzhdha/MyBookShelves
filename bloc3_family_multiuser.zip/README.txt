Bloc 3 - Mode "Bibliothèque Famille" (multi-user offline, partageable)

Objectif
- Plusieurs membres sur le même appareil OU import/export de bibliothèques entre membres.
- Note/Avis restent au niveau "exemplaire", MAIS chaque membre peut aussi avoir ses propres notes/avis
  sur une oeuvre/exemplaire via une table "UserCopyMeta" (sans casser Bloc 1/2).

Principe (additif, compatible blocs 1/2)
- On conserve:
  - Books = oeuvre
  - Copies = exemplaire (physique), avec champs rating/review "par défaut" (ex: propriétaire)
- On ajoute:
  - Users = profils
  - UserCopyMeta = métadonnées par utilisateur et par exemplaire (rating/review/status/loan, etc.)
  - ActiveUser = stockage local (SharedPreferences) pour "qui utilise l'app"

Fonctionnalités incluses dans ce bloc
1) Gestion des utilisateurs (CRUD simple)
2) Sélection de l'utilisateur actif
3) Saisie note/avis "pour moi" (utilisateur actif) sur un exemplaire (sans écraser l'autre)
4) Export/Import ZIP "family" incluant users + userCopyMeta en plus (format v3)

Intégration
- Modifier lib/db/app_db.dart:
  - Ajouter tables Users, UserCopyMetas à @DriftDatabase(tables:[...])
  - Passer schemaVersion -> 3
  - Ajouter migration (createTable users, userCopyMetas)
- Regénérer Drift:
  flutter pub run build_runner build --delete-conflicting-outputs

Dépendances à ajouter
- shared_preferences: ^2.2.3
- (Bloc 1 déjà: archive, file_picker, share_plus, drift, etc.)

Fichiers fournis
- lib/db/family_tables.dart : définitions Drift (Users, UserCopyMetas) + helpers de normalisation
- lib/services/family_transfer_service.dart : export/import ZIP v3 (users + user metas)
- lib/state/active_user_store.dart : utilisateur actif via SharedPreferences
- lib/ui/users_page.dart : UI gestion + sélection utilisateur actif
- lib/ui/copy_my_review_page.dart : UI note/avis "pour moi" (UserCopyMeta)

Notes
- Pour rester compatible, CopyFormPage (Bloc 2) continue d'éditer Copies.rating/review (exemplaire global).
- Pour l'expérience "famille", on recommande:
  - Dans BookDetailPage, ajouter un bouton "Mon avis" ouvrant CopyMyReviewPage.
