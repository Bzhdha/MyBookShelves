Bloc 1 - DB + Models + Services (Flutter / Drift)

Contenu:
- lib/db/app_db.dart : schéma v2 (Books=oeuvre, Copies=exemplaire avec note/avis), queries principales.
- lib/models/export_model.dart : export/import JSON (version 2) incluant copies.
- lib/services/cover_cache_service.dart : cache local des couvertures (covers/<bookId>.*).
- lib/services/library_transfer_service.dart : export ZIP + import avec ImportPlan + conflits (WorkConflict).

A faire côté projet:
1) Ajouter dépendances:
   drift, drift_flutter, drift_dev, build_runner
   archive, archive_io, file_picker, share_plus, path_provider

2) Générer app_db.g.dart:
   flutter pub run build_runner build --delete-conflicting-outputs

3) UI (Bloc 2):
   - ImportReviewPage pour éditer plan.conflicts[].choice
   - BookDetailPage + CopyFormPage (note/avis au niveau exemplaire)
