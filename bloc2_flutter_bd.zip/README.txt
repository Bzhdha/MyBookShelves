Bloc 2 - UI (Book detail + Copies + Import review)

Contenu:
- book_detail_page.dart : détail œuvre + liste exemplaires.
- copy_form_page.dart : formulaire exemplaire (note/avis au niveau copie).
- import_review_page.dart : écran résolution conflits (WorkConflict).

Intégration:
1) Injecter AppDb via Provider.
2) Lors d'un import:
   - plan = buildImportPlanFromZip(zip)
   - Navigator.push(ImportReviewPage(plan, onApply: (p) => applyImportPlanFromZip(zipFile: zip, plan: p)))
3) Après apply, refresh state.

Ce bloc suppose que Bloc 1 est déjà intégré.
